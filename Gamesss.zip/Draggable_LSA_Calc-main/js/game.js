const gameData = [
    { height: 5, length: 3, width: 2, area: 50 },
    { height: 4, length: 4, width: 4, area: 64 },
    { height: 3, length: 5, width: 6, area: 66 },
    { height: 2, length: 6, width: 8, area: 56 }
];

const optionsContainer = document.querySelector('.options-container');
const dropArea = document.querySelector('.drop-area');
const scoreContainer = document.querySelector('#score');
const checkAnswerBtn = document.querySelector('#checkAnswer');
const resultContainer = document.querySelector('#result');
const resetBtn = document.createElement('button');
resetBtn.textContent = 'Reset';

let selectedValues = { length: null, width: null, height: null };
let score = 0;
let currentProblem = 0;

const correctSound = new Audio('../assets/audio/correct.wav');
const incorrectSound = new Audio('../assets/audio/incorrect.wav');
const backgroundMusic = new Audio('../assets/audio/background.mp3');
backgroundMusic.loop = true;
backgroundMusic.volume = 0.2;

const celebrationAnimation = document.createElement('img');
celebrationAnimation.src = '../assets/images/smiley.png';
celebrationAnimation.style.display = 'none';

function generateOptions() {
    const optionSets = optionsContainer.querySelectorAll('.option-set');
    optionSets.forEach(set => {
        const setName = set.querySelector('.droppable-list').dataset.set;
        const values = new Set(gameData.map(item => item[setName]));
        set.querySelector('ul').innerHTML = [...values].map(value => `<li draggable="true" data-value="${value}">${value} cm</li>`).join('');
    });
}

function handleDragStart(e) {
    e.dataTransfer.setData('text/plain', null);
}

function handleDragOver(e) {
    e.preventDefault();
}

function handleDrop(e) {
    e.preventDefault();
    const data = e.dataTransfer.getData('text/plain');
    const draggedElement = document.querySelector(`[draggable="true"][data-value="${data}"]`);

    if (draggedElement) {
        const setName = draggedElement.parentNode.dataset.set;
        const value = parseInt(draggedElement.dataset.value);
        selectedValues[setName] = value;
        e.target.appendChild(draggedElement);
    }
}

function checkAnswer() {
    const { length, width, height } = selectedValues;
    const area = 2 * height * (length + width);
    const correctAnswer = gameData[currentProblem];

    if (correctAnswer && correctAnswer.area === area) {
        score++;
        scoreContainer.textContent = `Score: ${score}`;
        correctSound.play();
        resultContainer.innerHTML = `<p>Correct!</p>`;
        celebrationAnimation.style.display = 'block';
        setTimeout(() => {
            celebrationAnimation.style.display = 'none';
        }, 2000);
    } else {
        incorrectSound.play();
        resultContainer.innerHTML = `<p>Incorrect. The correct answer is: ${correctAnswer.height} cm, ${correctAnswer.length} cm, ${correctAnswer.width} cm</p>`;
    }

    currentProblem++;
    if (currentProblem === gameData.length) {
        currentProblem = 0;
        score = 0;
        resultContainer.innerHTML = `<p>Game over! Your final score is ${score}.</p>`;
        resetGame();
    } else {
        dropArea.innerHTML = '';
    }

    selectedValues = {};
}

function resetGame() {
    selectedValues = {};
    dropArea.innerHTML = '';
    score = 0;
    scoreContainer.textContent = `Score: ${score}`;
    resultContainer.innerHTML = '';
    generateOptions();
}

optionsContainer.addEventListener('dragstart', handleDragStart);
dropArea.addEventListener('dragover', handleDragOver);
dropArea.addEventListener('drop', handleDrop);
checkAnswerBtn.addEventListener('click', checkAnswer);
resetBtn.addEventListener('click', resetGame);

function initGame() {
    generateOptions();
    resultContainer.appendChild(celebrationAnimation);
    resultContainer.appendChild(resetBtn);


    document.addEventListener('click', function () {
        backgroundMusic.play();
        document.removeEventListener('click', arguments.callee);
    });
}

initGame();